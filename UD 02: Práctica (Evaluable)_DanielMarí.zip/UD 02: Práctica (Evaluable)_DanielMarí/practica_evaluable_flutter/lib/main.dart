import 'package:flutter/material.dart';
import 'themes/app_theme.dart';
import 'screens/marcador_screen.dart';

void main() {
  runApp(const MarcadorApp());
}

/// Widget raíz que configura la aplicación y el tema visual global.
class MarcadorApp extends StatelessWidget {
  const MarcadorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Marcador Deportivo',
      debugShowCheckedModeBanner: false,
      // Aplicación del tema oscuro global definido en themes/
      theme: AppTheme.temaOscuro,
      home: const MarcadorScreen(),
    );
  }
}
