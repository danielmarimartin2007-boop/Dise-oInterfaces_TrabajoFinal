import 'package:flutter/material.dart';
import '../themes/app_theme.dart';

class MiniMarcadorWidget extends StatelessWidget {
  final int puntuacionLocal;
  final int puntuacionVisita;

  const MiniMarcadorWidget({
    super.key,
    required this.puntuacionLocal,
    required this.puntuacionVisita,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: AppTheme.colorFondoMiniMarcador,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.colorBordeClaro),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Indicador visual Local
          Row(
            children: const [
              Icon(Icons.fiber_manual_record, color: Colors.blue, size: 12),
              SizedBox(width: 6),
              Text(
                'LOCAL',
                style: TextStyle(
                  color: Colors.blue,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          // Contenedor central con las puntuaciones
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(
              color: AppTheme.colorFondoCentroPuntuacion,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                Text(
                  '$puntuacionLocal',
                  style: const TextStyle(
                    color: Colors.blue,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(width: 22),
                const Text(
                  'vs',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                ),
                const SizedBox(width: 22),
                Text(
                  '$puntuacionVisita',
                  style: const TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
          // Indicador visual Visita
          Row(
            children: const [
              Text(
                'VISITA',
                style: TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              SizedBox(width: 6),
              Icon(Icons.fiber_manual_record, color: Colors.red, size: 12),
            ],
          ),
        ],
      ),
    );
  }
}