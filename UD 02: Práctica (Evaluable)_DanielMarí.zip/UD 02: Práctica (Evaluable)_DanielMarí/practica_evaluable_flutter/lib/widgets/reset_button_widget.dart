import 'package:flutter/material.dart';
import '../themes/app_theme.dart';

class ResetButtonWidget extends StatelessWidget {
  final VoidCallback alPulsarReset;

  const ResetButtonWidget({
    super.key,
    required this.alPulsarReset,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 180,
      height: 35,
      child: OutlinedButton.icon(
        onPressed: alPulsarReset,
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: AppTheme.colorBordeGris),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          backgroundColor: AppTheme.colorBotonResetFondo,
        ),
        icon: const Icon(Icons.refresh, color: Colors.white, size: 22,),
        label: const Text(
          'RESET',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
          ),
        ),
      ),
    );
  }
}