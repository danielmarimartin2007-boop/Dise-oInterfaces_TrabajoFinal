import 'package:flutter/material.dart';

class EquipoCardWidget extends StatelessWidget {
  final String nombreEquipo;
  final int puntuacion;
  final Color colorBase;
  final Color colorCentro;
  final Color colorPie;
  final EdgeInsetsGeometry margen;
  final VoidCallback alPulsarSumar;
  final VoidCallback alPulsarRestar;

  const EquipoCardWidget({
    super.key,
    required this.nombreEquipo,
    required this.puntuacion,
    required this.colorBase,
    required this.colorCentro,
    required this.colorPie,
    required this.margen,
    required this.alPulsarSumar,
    required this.alPulsarRestar,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margen,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: colorBase,
      ),
      child: Column(
        children: [
          // Botón superior +
          Expanded(
            flex: 2,
            child: InkWell(
              onTap: alPulsarSumar,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
              child: const Center(
                child: Icon(Icons.add, color: Colors.white, size: 58),
              ),
            ),
          ),
          // Pantalla central con la puntuación grande
          Expanded(
            flex: 4,
            child: Container(
              color: colorCentro,
              alignment: Alignment.center,
              child: Text(
                '$puntuacion',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 72,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          // Botón inferior -
          Expanded(
            flex: 2,
            child: InkWell(
              onTap: alPulsarRestar,
              child: const Center(
                child: Icon(Icons.remove, color: Colors.white, size: 58),
              ),
            ),
          ),
          // Pie de la tarjeta: Etiqueta del equipo
          Container(
            height: 28,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: colorPie,
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
            ),
            child: Text(
              nombreEquipo,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.1,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }
}