import 'package:flutter/material.dart';
import '../themes/app_theme.dart';
import '../widgets/mini_marcador_widget.dart';
import '../widgets/equipo_card_widget.dart';
import '../widgets/reset_button_widget.dart';

// Pantalla principal del marcador.
class MarcadorScreen extends StatefulWidget {
  const MarcadorScreen({super.key});

  @override
  State<MarcadorScreen> createState() => MarcadorScreenState();
}

class MarcadorScreenState extends State<MarcadorScreen> {
  // Variables de estado para las puntuaciones
  int puntuacionLocal = 0;
  int puntuacionVisitante = 0;

  // --- Métodos ---

  // Suma la puntuación en 1 punto según el equipo recibido ('local' o 'visitante').
  void sumar(String equipo) {
    setState(() {
      if (equipo == 'local') {
        puntuacionLocal++;
      } else if (equipo == 'visitante') {
        puntuacionVisitante++;
      }
    });
  }

  /// Restar la puntuación en 1 punto según el equipo recibido (mínimo 0).
  void restar(String equipo) {
    setState(() {
      if (equipo == 'local') {
        if (puntuacionLocal > 0) {
          puntuacionLocal--;
        }
      } else if (equipo == 'visitante') {
        if (puntuacionVisitante > 0) {
          puntuacionVisitante--;
        }
      }
    });
  }

  /// Restablece ambas puntuaciones a cero.
  void reiniciar() {
    setState(() {
      puntuacionLocal = 0;
      puntuacionVisitante = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: const [
            Icon(Icons.sports_basketball_outlined, color: Colors.white, size: 24),
            SizedBox(width: 10),
            Text(
              'MARCADOR',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // --- Marcador superior ---
              MiniMarcadorWidget(
                puntuacionLocal: puntuacionLocal,
                puntuacionVisita: puntuacionVisitante,
              ),
              const SizedBox(height: 16),

              // --- Tarjetas principales de los equipos ---
              Expanded(
                child: Row(
                  children: [
                    // Columna Equipo Local
                    Expanded(
                      child: EquipoCardWidget(
                        nombreEquipo: 'EQUIPO LOCAL',
                        puntuacion: puntuacionLocal,
                        colorBase: AppTheme.azulLocalBase,
                        colorCentro: AppTheme.azulLocalCentro,
                        colorPie: AppTheme.azulLocalCentro,
                        margen: const EdgeInsets.only(right: 8),
                        alPulsarSumar: () => sumar('local'),
                        alPulsarRestar: () => restar('local'),
                      ),
                    ),
                    // Columna Equipo Visita
                    Expanded(
                      child: EquipoCardWidget(
                        nombreEquipo: 'EQUIPO VISITA',
                        puntuacion: puntuacionVisitante,
                        colorBase: AppTheme.rojoVisitaBase,
                        colorCentro: AppTheme.rojoVisitaCentro,
                        colorPie: AppTheme.rojoVisitaCentro,
                        margen: const EdgeInsets.only(left: 8),
                        alPulsarSumar: () => sumar('visitante'),
                        alPulsarRestar: () => restar('visitante'),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // --- Botón RESET ---
              ResetButtonWidget(
                alPulsarReset: reiniciar,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

