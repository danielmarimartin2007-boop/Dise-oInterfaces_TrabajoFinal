import 'package:flutter/material.dart';

class AppTheme {
  // Fondos generales
  static const Color colorFondoScaffold = Color(0xFF121417);
  static const Color colorFondoMiniMarcador = Color(0xFF1A1D24);
  static const Color colorFondoCentroPuntuacion = Color(0xFF0F1115);

  // Equipo Local
  static const Color azulLocalBase = Color(0xFF1E88E5);
  static const Color azulLocalCentro = Color(0xFF2B52B2);

  // Equipo Visitante
  static const Color rojoVisitaBase = Color(0xFFE53935);
  static const Color rojoVisitaCentro = Color(0xFFB22B2B);

  // Botón Reset y bordes
  static const Color colorBotonResetFondo = Color(0xFF343434);
  static const Color colorBordeGris = Color(0xFF777777);
  static const Color colorBordeClaro = Color(0xFF606060);

  /// Tema oscuro global de la aplicación.
  static ThemeData get temaOscuro {
    return ThemeData.dark().copyWith(
      scaffoldBackgroundColor: colorFondoScaffold,
      appBarTheme: const AppBarTheme(
        backgroundColor: colorFondoScaffold,
        elevation: 0,
      ),
    );
  }
}